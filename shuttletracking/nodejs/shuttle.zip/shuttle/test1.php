<!DOCTYPE HTML>
<html><head>
        <title>Code review for Snipet</title>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
        <script type="text/javascript" src="http://www.way.com/node/socket.io/socket.io.js"></script>
        <script>
            var totalArray = [];
            totalArray.push({'lat': "23.076068", 'lon': "72.529325", 'heading': "358.828800713229", 'Previous_DTP_TripStopID':"172"});
            totalArray.push({'lat': "23.076418", 'lon': "72.529437", 'heading': "16.4041604634259", 'Previous_DTP_TripStopID':"172"});
            totalArray.push({'lat': "23.076883", 'lon': "72.529561", 'heading': "13.7840470387713", 'Previous_DTP_TripStopID':"172"});
            totalArray.push({'lat': "23.077213", 'lon': "72.529631", 'heading': "11.0423212586258", 'Previous_DTP_TripStopID':"172"});
           totalArray.push({'lat': "23.077500", 'lon': "72.529708", 'heading': "13.8647924084812", 'Previous_DTP_TripStopID':"172"});
           totalArray.push({'lat': "23.077866", 'lon': "72.529813", 'heading': "14.7847694759211", 'Previous_DTP_TripStopID':"172"});
           totalArray.push({'lat': "23.077964", 'lon': "72.529888", 'heading': "35.1478710765529", 'Previous_DTP_TripStopID':"172"});
           totalArray.push({'lat': "23.077960", 'lon': "72.530037", 'heading': "91.6714691352242", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077938", 'lon': "72.530336", 'heading': "94.5727331687107", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077908", 'lon': "72.530690", 'heading': "95.263102138158", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077901", 'lon': "72.531049", 'heading': "91.2141888803159", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077899", 'lon': "72.531542", 'heading': "90.2526550167097", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077899", 'lon': "72.532068", 'heading': "90.0", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077869", 'lon': "72.532497", 'heading': "94.3468755844616", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077879", 'lon': "72.532980", 'heading': "88.7107796671971", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077869", 'lon': "72.533409", 'heading': "91.4514342755375", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077879", 'lon': "72.533795", 'heading': "88.3869585925735", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077865", 'lon': "72.533958", 'heading': "95.3337288762112", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077832", 'lon': "72.534033", 'heading': "115.56061694479", 'Previous_DTP_TripStopID':"173"});
           totalArray.push({'lat': "23.077634", 'lon': "72.534039", 'heading': "178.403122026976", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.077411", 'lon': "72.534058", 'heading': "175.518117314357", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.077137", 'lon': "72.534101", 'heading': "171.784634501553", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.076919", 'lon': "72.534086", 'heading': "183.622063893152", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.076652", 'lon': "72.534082", 'heading': "180.789627807001", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.076344", 'lon': "72.534090", 'heading': "178.631140863569", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.076067", 'lon': "72.534081", 'heading': "181.712129140218", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.075892", 'lon': "72.534071", 'heading': "183.009304610807", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.075795", 'lon': "72.534093", 'heading': "168.213949513349", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.075744", 'lon': "72.534083", 'heading': "190.225598222183", 'Previous_DTP_TripStopID':"174"});
           totalArray.push({'lat': "23.075709", 'lon': "72.533882", 'heading': "259.282208830244", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075699", 'lon': "72.533692", 'heading': "266.725734854013", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075671", 'lon': "72.533469", 'heading': "262.228252717164", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075618", 'lon': "72.533005", 'heading': "262.922474432818", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075562", 'lon': "72.532510", 'heading': "262.989513555341", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075553", 'lon': "72.531954", 'heading': "268.991994257013", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075535", 'lon': "72.531394", 'heading': "267.998996193399", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075577", 'lon': "72.530814", 'heading': "274.500563535103", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075609", 'lon': "72.530538", 'heading': "277.182862690244", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075672", 'lon': "72.530250", 'heading': "277.182862690244", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075716", 'lon': "72.529941", 'heading': "283.375120861335", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075743", 'lon': "72.529757", 'heading': "279.062409159359", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075761", 'lon': "72.529541", 'heading': "275.17578110602", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075782", 'lon': "72.529397", 'heading': "279.00739105687", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075820", 'lon': "72.529342", 'heading': "306.906500126463", 'Previous_DTP_TripStopID':"175"});
           totalArray.push({'lat': "23.075888", 'lon': "72.529329", 'heading': "350.024849706338", 'Previous_DTP_TripStopID':"172"});
           totalArray.push({'lat': "23.076068", 'lon': "72.529325", 'heading': "358.828800713229", 'Previous_DTP_TripStopID':"172"});
            

            var socket = io.connect('http://www.way.com/', {path: '/node/socket.io', transports: ["polling"]});
            $(document).ready(function () {
                

                socket.on('connect', function (data) {
                    for(var i=10;i<=10;i++){
                        socket.emit('joinRoom', '1010', i, 'Driver');
                    }
                    
                });

                //sendmsg(totalArray);

            });

            function sendmsg(totalArray, driverid)
            {
                (function () {
                    var i = 0,
                            action = function () {
                                lat = totalArray[i].lat;
                                lon = totalArray[i].lon;
                                heading = totalArray[i].heading;
                                Previous_DTP_TripStopID = totalArray[i].Previous_DTP_TripStopID;
                                var driverDetail = {"current_timestamp": "1480948550", "user_name": "Ankit Solanki"+driverid, "Previous_DTP_TripStopID": Previous_DTP_TripStopID, "speed": "0.0", "lng": lon, "type": "Driver", "user": driverid, "DTP_DLG_DriverTripLogID": "19", "heading": heading, "lat": lat, "room": "1010"}
                                console.log(driverDetail);
                                socket.emit('track', driverDetail);
                                i++;
                                if (i < 100) {
                                    setTimeout(action, 1000);
                                } else {
                                    socket.emit('leave', "1010", driverid, "driver");
                                }
                            };

                    setTimeout(action, 1000);
                    
                })();
                
            }

		function sendallcar(){
			$(".sendallcar").trigger('click');
		}
        </script>
    </head>
    <body>
	<input type="button" onclick="sendallcar()" value="Click on all cars"><br/><br/>
        <?php 
        for($i=1; $i<=10; $i++){
        ?>
        <input type="button" class="sendallcar" onclick="sendmsg(totalArray, <?php echo $i;?>)" value="Send Car Info <?php echo $i;?>">
        <?php }?>
    </body>
</html> 
