-- MySQL dump 10.13  Distrib 5.5.57, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: waybi
-- ------------------------------------------------------
-- Server version	5.5.57-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_shuttle_active_status`
--

DROP TABLE IF EXISTS `tbl_shuttle_active_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_shuttle_active_status` (
  `SAS_ActiveID` int(11) NOT NULL AUTO_INCREMENT,
  `SAS_PatkingID` int(11) NOT NULL,
  `SAS_ShuttleActive` enum('0','1') NOT NULL DEFAULT '0',
  `SAS_ShuttleActive_LastTime` datetime NOT NULL,
  `SAS_ShuttleActive_LastTime_1Hour` datetime NOT NULL,
  `SAS_ShuttleActive_LastTime_2Hour` datetime NOT NULL,
  `SAS_ShuttleActive_LastTime_3Hour` datetime NOT NULL,
  PRIMARY KEY (`SAS_ActiveID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_shuttle_active_status`
--

LOCK TABLES `tbl_shuttle_active_status` WRITE;
/*!40000 ALTER TABLE `tbl_shuttle_active_status` DISABLE KEYS */;
INSERT INTO `tbl_shuttle_active_status` VALUES (1,575,'0','2017-03-27 15:25:48','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,1010,'0','2017-08-30 07:24:34','2017-08-30 07:24:34','2017-08-30 07:24:34','2017-08-30 07:24:34'),(3,717,'1','2017-10-10 11:25:47','2017-10-10 11:25:47','2017-10-10 11:25:47','2017-10-10 11:25:47'),(4,55,'0','2017-09-06 00:00:00','2017-09-06 00:00:00','2017-09-06 00:00:00','2017-09-06 00:00:00');
/*!40000 ALTER TABLE `tbl_shuttle_active_status` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `InsertOnlineStatusLog` BEFORE INSERT ON `tbl_shuttle_active_status` FOR EACH ROW BEGIN

INSERT INTO tbl_shuttle_offline_parking_log 
(SOPL_ParkingID,SOPL_CreatedDateTime,SOPL_StatrtDateTime,SOPL_EndDateTime,
SOPL_TotalMinutes)values
(new.SAS_PatkingID,now(),now(),'',0);

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `UpdateOnlineStatusLog` BEFORE UPDATE ON `tbl_shuttle_active_status` FOR EACH ROW BEGIN
If NEW.SAS_ShuttleActive  = 1 THEN

UPDATE tbl_shuttle_offline_parking_log SET SOPL_EndDateTime =  now() ,
SOPL_TotalMinutes = TIMESTAMPDIFF(MINUTE, SOPL_StatrtDateTime, NOW()) 
WHERE SOPL_ParkingID = NEW.SAS_PatkingID ;

ELSEIF OLD.SAS_ShuttleActive  = 1 THEN

INSERT INTO tbl_shuttle_offline_parking_log 
(SOPL_ParkingID,SOPL_CreatedDateTime,SOPL_StatrtDateTime,SOPL_EndDateTime,
SOPL_TotalMinutes) VALUES
(NEW.SAS_PatkingID,now(),now(),'',0);

END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-10 11:36:24
