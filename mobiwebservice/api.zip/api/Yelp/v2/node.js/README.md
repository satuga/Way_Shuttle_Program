
# Node.js

[Node.js](http://nodejs.org/) module for interacting with Yelp's API v2.0, see [olalonde/node-yelp](https://github.com/olalonde/node-yelp).
