<?php
$template='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Way.com</title>
</head>

<body>
<table width="630" border="0" align="center" cellpadding="0" cellspacing="0" style="border:1px solid #00a7d4;">
  <tr>
    <td height="1014" valign="top" background="http://www.bi.way.com/alpha/template/images/img-topbg.gif" scope="col" style="background-repeat:no-repeat; background-position:top;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="21" scope="col">&nbsp;</td>
      </tr>
      <tr>
        <td height="91" valign="top" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="5%" height="92" scope="col">&nbsp;</td>
            <td width="36%" scope="col">&nbsp;</td>
            <td width="59%" valign="top" scope="col"><table width="90%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="26" scope="col">&nbsp;</td>
              </tr>
              <tr>
                <td height="31" scope="col"><div align="center" style="font-family: Bookman Old Style, Arial, Helvetica, sans-serif; font-size: 30px; font-weight: normal; font-style: italic; color: #FFFFFF;">Welcome to Way.com! </div></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="109" valign="top" scope="col"><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="25" scope="col">&nbsp;</td>
          </tr>
          <tr>
            <td scope="col"><div align="center" style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; color: #FFFFFF; line-height: 24px; letter-spacing:0.5px;">Every morning, you will find one exclusive deal waiting in your inbox. We cant wait to help you discover huge discounts on all the cool things to do in your city.</div></td>
          </tr>
        </table></td>
      </tr>
	 <tr>
        <td height="40" scope="col">&nbsp;</td>
      </tr>
      <tr>
        <td scope="col" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; line-height:18px;" >DETAILS</td>
      </tr>
	  <tr>
        <td height="10" scope="col"></td>
      </tr>
	  <tr>
        <td height="56" scope="col"><table width="94%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">
              <div align="left"><span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">Sincerely,</span><br />
             <span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: bold; line-height:22px; color:#4e4e4e;">The Way.com Team</span><br />
               <a href="http://www.bi.way.com/alpha/"><span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#0b9fd8;">www.bi.way.com</span></a></div>
            </div></td>
          </tr>
        </table></td>
      </tr>
	  <tr>
        <td height="10" scope="col"></td>
      </tr>
      <tr>
        <td height="91" scope="col">
			<table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tr>
				<td width="33%" align="center">
				<a href="http://www.bi.way.com/alpha/"><img src="http://www.bi.way.com/alpha/template/images/img_features1.gif" border="0" /></a>
				</td>
				<td width="33%" align="center">
				<a href="http://www.bi.way.com/alpha/login.php"><img src="http://www.bi.way.com/alpha/template/images/img_features2.gif" border="0" /></a>
				</td>
				<td width="33%" align="center">
				<a href="http://www.bi.way.com/alpha/feedback.php"><img src="http://www.bi.way.com/alpha/template/images/img_features3.gif" border="0" /></a>
				</td>
			</tr>
			</table>
		</td>
      </tr>
      <tr>
        <td height="19" scope="col">&nbsp;</td>
      </tr>
      <tr>
        <td height="76" valign="top" scope="col"><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="15" colspan="5" scope="col"><div align="center" style="font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: normal; color: #0b9fd8;">...and dont forget to keep in touch:</div></td>
          </tr>
          <tr>
            <td height="7" colspan="5" scope="col"></td>
          </tr>
          <tr>
            <td width="37%" height="30" scope="col">&nbsp;</td>
            <td width="9%" scope="col"><div align="center"><a href="http://www.twitter.com/waycom" target="_blank"><img src="http://www.bi.way.com/alpha/template/images/119.png" width="28" height="28" border="0" /></a></div></td>
            <td width="9%" scope="col"><div align="center"><a href="http://www.facebook.com/waydotcom" target="_blank"><img src="http://www.bi.way.com/alpha/template/images/facebook_button.png" width="28" height="28" border="0" /></a></div></td>
            <td width="9%" scope="col"><div align="center"><a href="http://www.youtube.com/waychannel" target="_blank"><img src="http://www.bi.way.com/alpha/template/images/social_network_icons_youtube.png" width="28" height="28" border="0" /></a></div></td>
            <td width="36%" scope="col">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="217" valign="top" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0" style="border-bottom:1px dashed #0b9fd8; border-top:1px dashed #0b9fd8; background-color:#edf6fa">
          <tr>
            <td width="26%" height="258" valign="top" scope="col"><table width="86%" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td scope="col">&nbsp;</td>
              </tr>
              <tr>
                <td height="35" scope="col"><div align="left"><span style="font-family:Bookman Old style, Arial, Helvetica, sans-serif; font-size: 14px; font-style: italic; font-weight: normal; color: #0b9fd8; line-height: 22px;">Get ready</span> <br />
                  <span style="font-family:Bookman Old style, Arial, Helvetica, sans-serif; font-size: 14px; font-weight: normal; font-style: italic; color: #4e4e4e; line-height: 22px;">50% - 90% off the best in your city:</span></div></td>
              </tr>
              <tr>
                <td height="8" scope="col"></td>
              </tr>
              <tr>
                <td height="113" valign="top" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="8%" height="25" scope="col">&nbsp;</td>
                    <td width="13%" scope="col"><div align="left"><img src="http://www.bi.way.com/alpha/template/images/icon_arrow.png" width="10" height="8" /></div></td>
                    <td width="79%" scope="col"><div align="left" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; font-style:italic;">Activities</div></td>
                  </tr>
                  <tr>
                    <td height="25" scope="col">&nbsp;</td>
                    <td scope="col"><div align="left"><img src="http://www.bi.way.com/alpha/template/images/icon_arrow.png" width="10" height="8" /></div></td>
                    <td scope="col"><div align="left" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; font-style:italic;">Care</div></td>
                  </tr>
                  <tr>
                    <td height="25" scope="col">&nbsp;</td>
                    <td scope="col"><div align="left"><img src="http://www.bi.way.com/alpha/template/images/icon_arrow.png" width="10" height="8" /></div></td>
                    <td scope="col"><div align="left" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; font-style:italic;">Dine</div></td>
                  </tr>
                  <tr>
                    <td height="25" scope="col">&nbsp;</td>
                    <td scope="col"><div align="left"><img src="http://www.bi.way.com/alpha/template/images/icon_arrow.png" width="10" height="8" /></div></td>
                    <td scope="col"><div align="left" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; font-style:italic;">Park</div></td>
                  </tr>
                  <tr>
                    <td height="25" scope="col">&nbsp;</td>
                    <td scope="col"><div align="left"><img src="http://www.bi.way.com/alpha/template/images/icon_arrow.png" width="10" height="8" /></div></td>
                    <td scope="col"><div align="left" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; font-style:italic;">Ship</div></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td height="4" scope="col"></td>
              </tr>
              <tr>
                <td height="22" scope="col"><div align="left" style="font-family:Bookman Old style, Arial, Helvetica, sans-serif; font-size: 12px; font-style: italic; font-weight: normal; color: #0b9fd8; line-height: 22px;">See more recent deals</div></td>
              </tr>
            </table></td>
            <td width="1%" scope="col" style="border-left:1px dashed #0b9fd8;">&nbsp;</td>
            <td width="73%" valign="top" scope="col"><table width="94%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td scope="col">&nbsp;</td>
              </tr>
              <tr>
                <td scope="col"><div align="left"><span style="font-family:Bookman Old Style, Arial, Helvetica, sans-serif; font-size:14px; font-weight:normal; color:#0b9fd8;">What our over</span> <span style="font-family:Bookman Old Style, Arial, Helvetica, sans-serif; font-size:12px; font-weight:bold; color:#0b9fd8;">9 million customers</span> <span style="font-family:Bookman Old Style, Arial, Helvetica, sans-serif; font-size:14px; font-weight:normal; color:#0b9fd8;">are saying about Way.com:</span></div></td>
              </tr>
              <tr>
                <td scope="col" height="18"></td>
              </tr>
              <tr>
                <td scope="col"><div align="left" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; line-height:18px;">&ldquo;Way.com you are beyond awesome. You are the first e-mail I check everyday outside of work e-mail, I do have to pace myself however and fight the urge to NOT buy everything that comes up.&rdquo;</div></td>
              </tr>
			  <tr>
                <td scope="col" height="10"></td>
              </tr>
              <tr>
                <td scope="col"><div align="left" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:bold; color:#4e4e4e; line-height:18px;" >Missy Y, Yelp.com</div></td>
              </tr>
              <tr>
                <td scope="col" height="18"></td>
              </tr>
              <tr>
                <td scope="col"><div align="left" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; line-height:18px;">&ldquo;Hi. My name is Nektaria and Im addicted to Way.com.&rdquo;</div></td>
              </tr>
              <tr>
                <td scope="col" height="10"></td>
              </tr>
              <tr>
                <td scope="col"><div align="left" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:bold; color:#4e4e4e; line-height:18px;">Nektaria R, Yelp.com</div></td>
              </tr>
              <tr>
                <td scope="col">&nbsp;</td>
              </tr>
              <tr>
                <td scope="col"><div align="left"><a href="http://www.bi.way.com/alpha/" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:bold; color:#0b9fd8;">See more Way.com buzz</a> </div></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="14" scope="col"></td>
      </tr>
      <tr>
        <td height="35" scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:30px; font-weight: bold; color:#0b9fd8;">Thanks!</div></td>
      </tr>
      <tr>
        <td height="14" scope="col"></td>
      </tr>
      <tr>
        <td height="56" valign="top" scope="col"><table width="88%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">We hope you have as much fun using Way.com as we have working on it. And we crave your feedback: email us or call (877) 788-7858, where we have real humans that would love to speak with you.</div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="10" scope="col"></td>
      </tr>
      
      
    </table></td>
  </tr>
  <tr><td height="16" scope="col"></td></tr>
	  <tr><td height="1" bgcolor="#00a7d4"></td></tr>
	  <tr>
        <td bgcolor="#00a7d4" height="30" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#ffffff;padding-left:10px;">Deliverd by Way.com Inc. 830 Stewart Dr.Sunnyvale, CA 94085, USA</td>
      </tr>
	  <tr><td height="1" bgcolor="#00a7d4"></td></tr>
	  
	  <tr>
        <td bgcolor="#67c7e1" height="30" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight: normal; line-height:18px; color:#ffffff;padding-left:10px;padding-top:10px;">You are receiving this email because your are signed signed up in way.com. If you prefer not to receive the daily Way.com email, you can always <a href=""><font style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight: normal; line-height:18px; color:#ffffff;">unsubscribe</font></a> with one link. Be sure to add us your address book or safe sender list so emails get to your inbox.</td>
      </tr>
</table>
</body>
</html>'
?>