<?php
$template='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Way.com</title>
<style type="text/css">

	@font-face {
		font-family: \'din-mediumregular\';
		src: url(\'https://www.bi.way.com/fonts/dinm____-webfont.eot\');
		src: url(\'https://www.bi.way.com/fonts/dinm____-webfont.eot?#iefix\') format(\'embedded-opentype\'),
			 url(\'https://www.bi.way.com/fonts/dinm____-webfont.woff\') format(\'woff\'),
			 url(\'https://www.bi.way.com/fonts/dinm____-webfont.ttf\') format(\'truetype\'),
			 url(\'https://www.bi.way.com/fonts/dinm____-webfont.svg#din-mediumregular\') format(\'svg\');
		font-weight: normal;
		font-style: normal;
	
	}
	@font-face {
		font-family: \'UniversalDoomsdayBold\';
		src: url(\'https://www.bi.way.com/fonts/universal_doomsday_bold.eot\');
		src: url(\'https://www.bi.way.com/fonts/universal_doomsday_bold.eot\') format(\'embedded-opentype\'),
			 url(\'https://www.bi.way.com/fonts/universal_doomsday_bold.woff\') format(\'woff\'),
			 url(\'https://www.bi.way.com/fonts/universal_doomsday_bold.ttf\') format(\'truetype\'),
			 url(\'https://www.bi.way.com/fonts/fonts/universal_doomsday_bold.svg#UniversalDoomsdayBold\') format(\'svg\');
	}
	
	
	@font-face {
		font-family: \'din-boldregular\';
		src: url(\'https://www.bi.way.com/fonts/dinb____-webfont.eot\');
		src: url(\'https://www.bi.way.com/fonts/dinb____-webfont.eot?#iefix\') format(\'embedded-opentype\'),
			 url(\'https://www.bi.way.com/fonts/dinb____-webfont.woff\') format(\'woff\'),
			 url(\'https://www.bi.way.com/fonts/dinb____-webfont.ttf\') format(\'truetype\'),
			 url(\'https://www.bi.way.com/fonts/dinb____-webfont.svg#din-boldregular\') format(\'svg\');
		font-weight: normal;
		font-style: normal;
	
	}

</style>
</head>
<body>
<div style="width: 841px; height: auto; margin: 0 auto;">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
 
  <tr>
        <td height="10" scope="col"></td>
      </tr>
  <tr>
    <td valign="top">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
	
	<tr>
        <td height="10" scope="col"></td>
      </tr>
	<tr><td  colspan="3" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; line-height:18px;">
	DETAILS
 </td>
  </tr>
  <tr>
        <td height="20" scope="col"></td>
      </tr>
  <tr><td colspan="3">
  <div style="width: 841px; height: auto; margin: 0 auto;">
		<div style="position: relative; top: -7px; font: normal 14px din-mediumregular, Arial, Helvetica, sans-serif; color: #fff; text-transform: uppercase;">
		
			<table width="841" border="0" cellspacing="0" cellpadding="0">
				  <tr>
				  
					<td colspan="4" scope="col" valign="top">
					<table width="828" border="0" cellspacing="0" cellpadding="0">
					  <tr><td>
								
									<div style="font: normal 13px din-mediumregular, Arial, Helvetica, sans-serif; color: #000; text-transform: none; line-height: 22px;text-align:center;border-top: 1px solid #cfcfcf;padding-top:20px;">Questions? Please call Way.com at 408-598-3338 immediately or send an email to support@way.com.</div> 
								</td>
					   </tr>
				  </tr>
				  
				  <div style="clear: both;"></div>
			</table>
	  </div>
	 <div  style="padding-top:30px;"></div>
	<div align="center">
		
		<img src="https://www.bi.way.com/images/slogan.png" /><br/><img style="padding: 14px 0 44px 0;" src="https://www.bi.way.com/images/footer.png" />
		
	</div>  
	<div style="font: normal 13px UniversalDoomsdayBold, Arial, Helvetica, sans-serif; color: #000; text-transform: none; line-height: 22px;text-align:center;">It\'s your life, way makes it simpler.</div> 
	
		
  </div>
  </td></tr>
</table>
</div>
</body>
</html>'
?>