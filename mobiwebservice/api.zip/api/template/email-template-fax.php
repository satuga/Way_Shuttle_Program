<?php
$template='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Way.com</title>
</head>
<body>
<table width="800" border="0" align="center" cellpadding="0" cellspacing="4">
<tr>
     <td scope="col" align="left" style="text-align:left;margin-left:50px;"><img src="https://www.bi.way.com/template/images/waylogo.png" width="300" border="0"></td>
</tr>
<tr><td style="font-family:Arial, Helvetica, sans-serif; font-size:20px; font-weight:normal; color:#4e4e4e; line-height:18px;margin-left:50px;">Hi  CNAME!</td></tr>
<tr><td height="10"></td></tr>
<tr><td align="left" style="text-align:left;margin-left:50px;">
  DETAILS
</td></tr>
<tr><td height="20"></td></tr>
<tr><td style="font-family:Arial, Helvetica, sans-serif; font-size:18px; font-weight:normal; color:#4e4e4e; line-height:18px;text-align:center;">You can always email us with questions at support@way.com or call: 408-598-3338</td></tr>
<tr><td height="10"></td></tr>

<tr><td>
<div style="padding-top:30px;"></div>
<div align="center" margin: 0 auto;">
	
	<img src="https://www.bi.way.com/images/slogan.png" /><br/><img style="padding: 14px 0 44px 0;" src="https://www.bi.way.com/images/footer.png" />
	
</div> 
<div style="font: normal 16px UniversalDoomsdayBold, Arial, Helvetica, sans-serif; color: #000; text-transform: none; line-height: 22px;text-align:center;">We Are Way.com, we make life simple.</div> 
</td></tr>
</table>
</body>
</html>'
?>