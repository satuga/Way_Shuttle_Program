<?php
$template='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Way.com</title>
</head>

<body>
<table width="630" border="0" align="center" cellpadding="0" cellspacing="0" style="border:1px solid #00a7d4;">
  <tr>
    <td height="1014" valign="top" background="http://www.bi.way.com/alpha/template/images/img-topbg.gif" scope="col" style="background-repeat:no-repeat; background-position:top;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="21" scope="col">&nbsp;</td>
      </tr>
      <tr>
        <td height="91" valign="top" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="5%" height="92" scope="col">&nbsp;</td>
            <td width="36%" scope="col">&nbsp;</td>
            <td width="59%" valign="top" scope="col"><table width="90%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="26" scope="col">&nbsp;</td>
              </tr>
              <tr>
                <td height="31" scope="col"><div align="center" style="font-family: Bookman Old Style, Arial, Helvetica, sans-serif; font-size: 30px; font-weight: normal; font-style: italic; color: #FFFFFF;">Welcome to Way.com! </div></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="109" valign="top" scope="col"><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="25" scope="col">&nbsp;</td>
          </tr>
          <tr>
            <td scope="col"><div align="center" style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; color: #FFFFFF; line-height: 24px; letter-spacing:0.5px;">Every morning, you will find one exclusive deal waiting in your inbox. We cant wait to help you discover huge discounts on all the cool things to do in your city.</div></td>
          </tr>
        </table></td>
      </tr>
	 <tr>
        <td height="40" scope="col">&nbsp;</td>
      </tr>
      <tr>
        <td scope="col" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; line-height:18px;" >DETAILS</td>
      </tr>
	  <tr>
        <td height="4" scope="col">&nbsp;</td>
      </tr>
     
      <tr>
        <td height="19" scope="col">&nbsp;</td>
      </tr>
     
      <tr>
        <td height="217" valign="top" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0" style="border-bottom:1px dashed #0b9fd8; border-top:1px dashed #0b9fd8; background-color:#edf6fa">
          <tr>
            <td width="26%" height="258" valign="top" scope="col"><table width="86%" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td scope="col">&nbsp;</td>
              </tr>
              <tr>
                <td height="35" scope="col"><div align="left"><span style="font-family:Bookman Old style, Arial, Helvetica, sans-serif; font-size: 14px; font-style: italic; font-weight: normal; color: #0b9fd8; line-height: 22px;">Get ready</span> <br />
                  <span style="font-family:Bookman Old style, Arial, Helvetica, sans-serif; font-size: 14px; font-weight: normal; font-style: italic; color: #4e4e4e; line-height: 22px;">50% - 90% off the best in your city:</span></div></td>
              </tr>
              <tr>
                <td height="8" scope="col"></td>
              </tr>
              
              <tr>
                <td height="4" scope="col"></td>
              </tr>
              <tr>
                <td height="22" scope="col"><div align="left" style="font-family:Bookman Old style, Arial, Helvetica, sans-serif; font-size: 12px; font-style: italic; font-weight: normal; color: #0b9fd8; line-height: 22px;">See more recent deals</div></td>
              </tr>
            </table></td>
            <td width="1%" scope="col" style="border-left:1px dashed #0b9fd8;">&nbsp;</td>
            <td width="73%" valign="top" scope="col"></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="14" scope="col"></td>
      </tr>
      <tr>
        <td height="35" scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:30px; font-weight: bold; color:#0b9fd8;">Thanks!</div></td>
      </tr>
      <tr>
        <td height="14" scope="col"></td>
      </tr>
      <tr>
        <td height="56" valign="top" scope="col"><table width="88%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">We hope you have as much fun using Way.com as we have working on it. And we crave your feedback: email us or call (877) 788-7858, where we have real humans that would love to speak with you.</div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="33" scope="col"></td>
      </tr>
      <tr>
        <td height="56" scope="col"><table width="94%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">
              <div align="left"><span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">Sincerely,</span><br />
             <span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: bold; line-height:22px; color:#4e4e4e;"> The Way.com Team</span><br />
               <a href="http://www.bi.way.com/alpha/"><span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#0b9fd8;"> www.bi.way.com</span></a></div>
            </div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="16" scope="col"></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>'
/*<tr>
        <td height="91" scope="col"><div align="center"><img src="http://www.bi.way.com/alpha/template/images/img_features.gif" width="560" height="189" /></div></td>
      </tr>
      <tr>
        <td height="19" scope="col">&nbsp;</td>
      </tr>*/
?>