<?php
$template='<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
 <HEAD>
  <TITLE>Way.com</TITLE>
  <META NAME="Generator" CONTENT="EditPlus">
  <META NAME="Author" CONTENT="Way">
  <META NAME="Keywords" CONTENT="Way">
  <META NAME="Description" CONTENT="Way">
 </HEAD>

 <BODY>
	<table border="0" cellpadding="0" cellspacing="0" width="80%" align="center" style="border:2px solid #cccccc;">
		<tr>
			<td>
				<table border="0" cellpadding="0" cellspacing="0" width="100%" align="center">
					<tr>
						<td style="padding-left:5px;"><img src="http://www.way.com/alpha/images/img_logo.jpg" border="0" /></td>
						<td style="font:bold 24px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px; ">#4275632-0-1</td>
					</tr>
				</table>
			</td>
		</tr>
		<td height="2" bgcolor="#cccccc"></td>
		<tr><td height="15"></td></tr>
		<tr><td>
		DETAILS
		</td></tr>
		<tr><td height="15"></td></tr>
		<tr>
			<td>
				<table border="0" cellpadding="0" cellspacing="0" width="90%" style="padding-left:20px;">					
					<tr height="10">
						<td style="font:bold 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">Fine Print:</td>		
					</tr>
					<tr><td height="7"></td></tr>
					<tr height="10">
						<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">Limit 1 per person, may buy multiple as gifts. By appt.</td>		
					</tr>
					<tr height="10">
						<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">only. Non-transferable. Over 6 limited to 250lbs.</td>					
					</tr>
					<tr height="10">
						<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">Under 6 limited to 230lbs. Not valid for pregnant</td>					
					</tr>
					<tr height="10">
						<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">mothers or anyone with heart, neck, or back problem</td>					
					</tr>
					<tr height="10">
						<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">history. Tax not included. No weekends.</td>					
					</tr>
						<tr><td height="20"></td></tr>	
					<tr>
						<td style="font:bold 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">Universal Fine Print:.</td>
					</tr>
					<tr><td height="10"></td></tr>
					<tr>
						<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">Not valid for cash back (unless required by law). Must use in one visit.</td>
					</tr>
					<tr>
						<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">Doesn\'t cover tax or gratuity. Can\'t be combined with other offers.</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr><td height="20"></td></tr>	
	</table>	
    <table border="0" cellpadding="0" cellspacing="0" width="80%" align="center" style="padding-left:20px;">
	<tr><td height="25"></td></tr>	
		<tr>
			<td style="font:bold 18px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">How to use this:</td>
		</tr>
		<tr><td height="7"></td></tr>
		<tr>
			<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">1. Print your Way.com (or pull it up with our mobile app).</td>
		</tr>
		<tr>
			<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">2. Call (510) 489-4359 for appointment, mention your Way.com.</td>
		</tr>
		<tr>
			<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">3. Present Way.com upon arrival.</td>
		</tr>
		<tr>
			<td style="font:normal 14px Arial, Helvetica, Sans Serif; color: #000000; line-height:20px;">4. Enjoy!</td>
		</tr>
		<tr><td height="20"></td></tr>	
	</table>
	<table border="0" cellpadding="0" cellspacing="0" width="80%" height="5%" align="center">
		<tr>
			<td bgcolor="#cccccc" align="center">Way.com Support: (877) 788-7858 Monday-Friday 9am-5pm CST Email Way.com: support@way.com</td>
		</tr>
	</table>
 </BODY>
</HTML>';