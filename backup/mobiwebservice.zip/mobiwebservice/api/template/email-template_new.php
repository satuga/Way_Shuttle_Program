<?php
$template='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Way.com</title>
</head>

<body>
<table width="630" border="0" align="center" cellpadding="0" cellspacing="0" style="border:1px solid #00a7d4;">
  <tr>
    <td valign="top" background="http://www.way.com/alpha/template/images/img-topbg.gif" scope="col" style="background-repeat:no-repeat; background-position:top;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="21" scope="col">&nbsp;</td>
      </tr>
      <tr>
        <td height="91" valign="top" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="5%" height="92" scope="col">&nbsp;</td>
            <td width="36%" scope="col">&nbsp;</td>
            <td width="59%" valign="top" scope="col"><table width="90%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="26" scope="col">&nbsp;</td>
              </tr>
              <tr>
                <td height="31" scope="col"><div align="center" style="font-family: Bookman Old Style, Arial, Helvetica, sans-serif; font-size: 30px; font-weight: normal; font-style: italic; color: #FFFFFF;">Welcome to Way.com! </div></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="109" valign="top" scope="col"><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="25" scope="col">&nbsp;</td>
          </tr>
          <tr>
            <td scope="col"><div align="center" style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; color: #FFFFFF; line-height: 24px; letter-spacing:0.5px;">Every day, you\'ll find hundreds of service offerings on way.com. We can\'t wait to help you discover the best service providers with huge discounts in your neighborhood.</div></td>
          </tr>
        </table></td>
      </tr>
	  <tr>
        <td height="40" scope="col">&nbsp;</td>
      </tr>
      <tr>
        <td scope="col">DETAILS</td>
      </tr>
	  <tr>
        <td height="4" scope="col">&nbsp;</td>
      </tr>
      
      <tr>
        <td height="76" valign="top" scope="col"><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="15" colspan="5" scope="col"><div align="center" style="font-family: Arial, Helvetica, sans-serif; font-size: 12px; font-weight: normal; color: #0b9fd8;">...and dont forget to keep in touch:</div></td>
          </tr>
          <tr>
            <td height="7" colspan="5" scope="col"></td>
          </tr>
          <tr>
            <td width="37%" height="30" scope="col">&nbsp;</td>
            <td width="9%" scope="col"><div align="center"><a href="http://www.twitter.com/waycom" target="_blank"><img src="http://www.way.com/alpha/template/images/119.png" width="28" height="28" border="0" /></a></div></td>
            <td width="9%" scope="col"><div align="center"><a href="http://www.facebook.com/waydotcom" target="_blank"><img src="http://www.way.com/alpha/template/images/facebook_button.png" width="28" height="28" border="0" /></a></div></td>
            <td width="9%" scope="col"><div align="center"><a href="http://www.youtube.com/waychannel" target="_blank"><img src="http://www.way.com/alpha/template/images/social_network_icons_youtube.png" width="28" height="28" border="0" /></a></div></td>
            <td width="36%" scope="col">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
     
      <tr>
        <td height="14" scope="col"></td>
      </tr>
      <tr>
        <td height="35" scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:30px; font-weight: bold; color:#0b9fd8;">Thanks!</div></td>
      </tr>
      <tr>
        <td height="14" scope="col"></td>
      </tr>
      <tr>
        <td height="56" valign="top" scope="col"><table width="88%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">We hope you have as much fun using Way.com as we have working on it. And we crave your feedback: email us or call 408 524 4237, where we have real humans that would love to speak with you.</div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="33" scope="col"></td>
      </tr>
      <tr>
        <td height="56" scope="col"><table width="94%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">
              <div align="left"><span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">Sincerely,</span><br />
             <span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: bold; line-height:22px; color:#4e4e4e;"> The <a href="http://www.way.com"><span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;text-decoration:none">Way.com</span></a> Team</span><br />
             </div>
            </div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="16" scope="col"></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>'
/*<tr>
        <td height="91" scope="col"><div align="center"><img src="http://www.way.com/waybeta/template/images/img_features.gif" width="560" height="189" /></div></td>
      </tr>
      <tr>
        <td height="19" scope="col">&nbsp;</td>
      </tr>*/
?>