<?php
$template='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Way.com</title>
</head>
<body>
<table width="830" border="0" align="center" cellpadding="0" cellspacing="0" style="border:1px solid #00a7d4;">
  <tr>
    <td height="700" valign="top" background="http://www.way.com/alpha/template/images/img-topbg-1.gif" scope="col" style="background-repeat:no-repeat; background-position:top;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="21" scope="col">&nbsp;</td>
      </tr>
      <tr>
        <td height="91" valign="top" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="5%" height="92" scope="col">&nbsp;</td>
            <td width="36%" scope="col">&nbsp;</td>
            <td width="59%" valign="top" scope="col"><table width="90%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="26" scope="col">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
	<tr><td  colspan="3" style="font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#4e4e4e; line-height:18px;">
	DETAILS
 </td>
  </tr>
  <tr>
        <td height="10" scope="col"></td>
      </tr>
	<tr>
        <td height="56" scope="col"><table width="94%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">
              <div align="left"><span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#4e4e4e;">Sincerely,</span><br />
             <span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: bold; line-height:22px; color:#4e4e4e;">The Way.com Team</span><br />
               <a style="text-decoration:none;"href="http://www.way.com/alpha/"><span style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#0b9fd8;text-decoration:none;">www.way.com</span></a></div>
            </div></td>
          </tr>
        </table></td>
      </tr>
	  <tr>
        <td height="5" scope="col"></td>
      </tr>
	  <tr>
	  <td><img src="http://www.way.com/alpha/template/images/img_dotted.gif" border="0"></td>
	  </tr>
	<tr>
        <td height="8" scope="col"></td>
      </tr>
	<tr>
        <td height="35" scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:30px; font-weight: bold; color:#1A86B4;">Thanks!</div></td>
      </tr>
      <tr>
        <td height="14" scope="col"></td>
      </tr>
	  <tr>
        <td height="40" valign="top" scope="col"><table width="88%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td scope="col"><div align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:13px; font-weight: normal; line-height:22px; color:#4e4e4e;">
			If you have any comments or questions, please email or call us at (408) 598-3338, where we have real humans that would love to speak with you.</div></td>
          </tr>
        </table></td>
      </tr>
      <tr><td height="16" scope="col"></td></tr>
	  <tr><td height="1" bgcolor="#00a7d4"></td></tr>
	  <tr>
        <td bgcolor="#1487BD" height="30" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight: normal; line-height:22px; color:#ffffff;padding-left:10px;"><img src="http://www.way.com/alpha/template/images/logo_small.png" align="top"border="0"style="padding-top:5px;"/> Deliverd by Way.com Inc. 830 Stewart Dr.Sunnyvale, CA 94085, USA</td>
      </tr>
	  <tr><td height="1" bgcolor="#00a7d4"></td></tr>
</table>
<table width="630" border="0" align="center" cellpadding="0" cellspacing="0">
 <tr>
        <td height="30" style="font-family:Arial, Helvetica, sans-serif; font-size:11px; font-weight: normal; line-height:14px; color:#CBCBCB;padding-top:10px;">You are receiving this email because your are signed signed up in way.com. If you prefer not to receive the daily Way.com email, you can always <a href="http://www.way.com/alpha/unsubscribe.php"><font style="font-family:Arial, Helvetica, sans-serif; font-size:11px; font-weight: normal; line-height:14px; color:#CBCBCB;text-decoration:underline;">unsubscribe</font></a> with one link. Be sure to add us your address book or safe sender list so emails get to your inbox.</td>
      </tr>
</table>
</body>
</html>
</body>
</html>'
?>