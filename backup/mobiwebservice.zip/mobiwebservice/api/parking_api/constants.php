<?php
//-------- All the Constansts which are required in the API are defined over here ----//
define("DB_SERVER","10.168.1.93");
define("DB_USERNAME","letsnurt_wayapp");
define("DB_PASSWORD","67f6ddds78d7fhjkl98");
define("DB_DATABASE","letsnurt_wayapp");


define("ENCRYPTKEY","sapconf747");
define("CARDENCRYPT","L0M35r1j3mqcntZL");


define("REPLY_MAIL","support@way.com");
define("ADMINMAIL","support@way.com");
define("CONTACTMAIL","support@way.com");


define("HOSTPATH","http://192.169.219.151/~jumapar/steelengine/");
define("IMAGEPATH","http://192.169.219.151/~jumapar/steelengine/admin/upload/users/");

define("SUCCESS","success");
define("SUCCESS_MSG","Success");

define("PARAMETER_CODE","error");
define("PARAMETER_MSG","Parameter Missing");

define("DUPLICAT_CODE","error");
define("DUPLICAT_MSG","Duplicate Entry Not Allow");

define("INCORRECT_CODE","error");
define("INCORRECT_MSG","Invalid email or password!");

define("INCORRECT_LOGIN_CODE","error");
define("INCORRECT_LOGIN_MSG","Invalid email or password!");

define("ERROR","error");
define("ERROR_MSG","Something Went Wrong");

define("DOM_ERROR_CODE","error");
define("DOM_ERROR_MSG","Error while parsing the document");

define("REQUEST_SENT_CODE","error");
define("REQUEST_SENT_MSG","Request Already Sent!");

define("NO_USER_ON_MOBILE_CODE","error");
define("NO_USER_ON_MOBILE_MSG","Friend is not available on agryd mobile App!");

define("LOCATION_ERROR_CODE","error");
define("LOCATION_ERROR_MSG","Location not exist!");

define("NO_REQUEST_SENT","error");
define("NO_REQUEST_SENT_MSG","Sorry you have no any request !");



define("IMAHE_PATH_APP","https://www.agryd.com/file/pic/user/");

define("APP_IMAGE_PATH","https://www.agryd.com/api/app_user_images/");
define("ABOUT","<p>Agryd.com is probably the most popular Indian Social Networking Websites with various features embedded on a single platform. Agryd is a medium to get connected to your friend, family and folks all across the globe. Agryd�s key mission is to give people the power to share and make the world more open and connected.</p> 
<p>Agryd is a way to become fully social. It allows you to share your ideas and thoughts among public. The site is one of the most simplest and effective ways to do promotion of company or its products.</p>");

define("TERMS","<p>AGRYD have some terms to be followed for the users before joining it and before making use of services here. These terms are related to the information shared, photos, videos, music, shared here. These terms are required to be accepted and followed before accessing this site. By signing up and accessing the services you need to be agreeing to accept these terms.</p>
<ul><li>Basic terms: These terms include basic things to be followed. If you are using the services here, you are the only person who is responsible for your uses and any consequences. Things shared by you will be shown to the entire world so first you must be sure and comfortable about the content to be shared, it must be appropriate in all the aspects.Services provided by AGRYD are owned by it only so these can be changed anytime without any prior notice. AGRYD have all the rights to use the information provided by you and make changes in its rules and services anytime.</li><li>        Privacy Terms- User is needed to post and share anything only subject to our privacy policy. This website will not be responsible for anything else posted or shared. All the information used by you or shared by you must be gone through the policy and policy is must to be followed. We will be providing you information about anything new happening with us or any announcements will be shared with you. This type of communication things are part of services and you can�t keep you away from these. </li><li>        Passwords: While coming to passwords you will be the only responsible person for your security and the safety by selecting a strong password having high security. Password selected to make use of services here must be strong enough to stop the outsiders to steal your information. AGRYD will not be responsible for any type of loss or damages caused because of weak password selection.</li><li>       Content Terms: These terms asks to be sure and confident about each and every character of content created by you. Content created by you may be accessible to all the users registered over the website so you must be completely sure and responsible for the content created by you. Content posted by you through this service must be posted at your own risk. This site will not guarantee any completeness, authenticity, reliability or factuality of the content posted by you and you must be responsible for that. </li><li>       AGRYD rights: All the rights, title, rules, services, applications, and policies issued are the property of AGRYD and its licensors only. These all services are protected by laws of all countries, copyright, trademarks and many other things. You are not authorised to use name of AGRYD and its trademarks, brand features, brand names and logos anywhere. You are allowed to give feedback and suggestions for the site and this site is free to use those suggestion and feedback.</li><li>        Copyright terms: AGRYD respects other website�s intellectual property and information rights and it also expect the same from its users as well. If you are using any copied content which may constitute copyright infringement you are also need to provide some other information with that including copyright owner�s signature who is authorised to take any action, copyrighted work�s complete identification, sufficient information which allows to locate the copyrighted information or material, your complete contact information including name, address and email address, and a statement showing the correctness of information given by you.</li> </ul><p>These all terms will be applied on every user continuously till he/she is a using the services of AGRYD. The terms will end when the user leaves the site or terminated. AGRYD have all the rights to end your services by deactivating the account at any time for any reason.</p>");?>
